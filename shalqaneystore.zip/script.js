function orderProduct(productName, productPrice) {
    document.getElementById("product").value = productName;
    document.getElementById("price").value = productPrice + " ج.م";
    window.scrollTo(0, document.getElementById("payment").offsetTop);
}

document.getElementById("orderForm").addEventListener("submit", function(e) {
    e.preventDefault();
    document.getElementById("msg").innerHTML = "<p style='color:green;'>✅ تم استلام طلبك، سنتواصل معك لتأكيد الدفع.</p>";
    this.reset();
});